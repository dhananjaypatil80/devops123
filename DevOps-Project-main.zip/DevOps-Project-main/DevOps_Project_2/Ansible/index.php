<body bgcolor='white'>
<pre>
<?php
print("<b><font color=\"blue\">!! Hello !! This is Euran,\n\n! Welcome ! to My Web Server</font>\n\n");
print (`/usr/sbin/ifconfig`);
?>
</pre>
